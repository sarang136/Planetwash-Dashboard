import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const apiSlice = createApi({
  reducerPath: 'api',
  baseQuery: fetchBaseQuery({ baseUrl: `${import.meta.env.VITE_BACKEND_URL}` }),
  endpoints: (builder) => ({
    getUserOrders: builder.query({
      query: () => `/user/order/all`,
    }),
    getUserOrdersByStatus: builder.query({
      query: (status) => `/user/order/status/${status}`, 
    }),
    getAllServices: builder.query({
      query: () => `/shop/service/getservice`, 
    }),
    // getDeliveryBoyById: builder.query({
    //   query: (deliveryBoyId) => `/delivery/auth/get/${deliveryBoyId}`,
    // }),

  }),
});

export const {
  useGetUserOrdersQuery,
  useGetUserOrdersByStatusQuery,
  useGetAllServicesQuery,
} = apiSlice;
