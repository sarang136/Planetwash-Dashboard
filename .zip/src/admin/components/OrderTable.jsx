import React, { useState } from "react";
import { useGetUserOrdersQuery } from "../redux/appSlice";

const OrderTable = () => {
  const [showModal, setShowModal] = useState(false);
  const { data: allOrders, isLoading, isError } = useGetUserOrdersQuery();
  console.log(allOrders)
  if (isLoading) return <div>Loading orders...</div>;
  if (isError) return <div>Failed to fetch orders.</div>;

  const currentDateOrders = allOrders?.filter((order) => {
    const orderDate = new Date(order.createdAt).toDateString();
    const todayDate = new Date().toDateString();
    
    return orderDate === todayDate;
  });

  return (
    <div>
      <h1>Today's Orders</h1>
      {allOrders?.map((res, index) => (
        <div key={index}>
          <p></p>
        </div>
      ))}
    </div>







    // <div className="p-4 w-[100vw] md:w-[unset] ">
    //   <h3 className="text-lg font-semibold text-[#041434] mb-2">Today's Orders</h3>

    //   <div className="p-[0.7rem] bg-white rounded-xl shadow-md max-h-[40vh] overflow-y-scroll">
    //     <div className="bg-white rounded-xl overflow-hidden overflow-x-scroll ">
    //       <table className="min-w-full text-left text-[10px]">
    //         <thead className="text-[#041434] text-sm font-semibold">
    //           <tr>
    //             <th className="py-3 px-4 text-[12px] md:text-sm">Customer Name</th>
    //             <th className="py-3 px-4 text-[12px] md:text-sm">Contact No</th>
    //             <th className="py-3 px-4 text-[12px] md:text-sm">Email</th>
    //             <th className="py-3 px-4 text-[12px] md:text-sm">Service Type</th>
    //             <th className="py-3 px-4 text-[12px] md:text-sm">Address</th>
    //           </tr>
    //         </thead>
    //         <tbody className="text-sm text-gray-700 border-t ">
    //           {[...Array(8)].map((_, i) => (
    //             <tr key={i}>
    //               <td className="py-3 px-4 text-[12px] md:text-sm">John doe</td>
    //               <td className="py-3 px-4 text-[12px] md:text-sm">8978765654</td>
    //               <td className="py-3 px-4 text-[12px] md:text-sm">john@gmail.com</td>
    //               <td className="py-3 px-4 text-[12px] md:text-sm">Washing & Ironing</td>
    //               <td className="py-3 px-4 text-[12px] md:text-sm">Golden City Center, Chh Sambhajinagar</td>
    //               <td className="py-3 px-4 text-[12px] md:text-sm">
    //                 <button
    //                   onClick={() => setShowModal(true)}
    //                   className="p-2 bg-[rgba(5,35,68,1)] text-white rounded-lg text-[10px] md:text-[white] whitespace-nowrap"
    //                 >
    //                   Schedule Pickup
    //                 </button>
    //               </td>
    //             </tr>
    //           ))}
    //         </tbody>
    //       </table>
    //     </div>
    //   </div>

    //   {/* MODAL */}
    //   {showModal && (
    //     <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50">
    //       <div className="bg-white p-6 md:p-10 rounded-[40px] shadow-lg w-[90%] md:w-[700px] flex flex-col md:flex-row gap-6 relative">
    //         {/* Close button */}
    //         <button
    //           onClick={() => setShowModal(false)}
    //           className="absolute top-4 right-4 text-gray-500 hover:text-gray-800 text-2xl"
    //         >
    //           &times;
    //         </button>

    //         {/* Calendar mockup */}
    //         <div className="flex-1">
    //           <h2 className="text-lg font-semibold mb-4">June 2025</h2>
    //           <div className="grid grid-cols-7 gap-2 text-center text-sm">
    //             {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((day, i) => (
    //               <div key={i} className="font-bold">{day}</div>
    //             ))}
    //             {[...Array(30)].map((_, i) => (
    //               <button
    //                 key={i}
    //                 className={`py-1 rounded-full ${i === 7 ? "bg-[rgba(5,35,68,1)] text-white" : "hover:bg-gray-200"
    //                   }`}
    //               >
    //                 {i + 1}
    //               </button>
    //             ))}
    //           </div>
    //         </div>

    //         {/* Time selection */}
    //         <div className="flex-1">
    //           <h2 className="text-lg font-semibold mb-4">Select Time</h2>
    //           <input
    //             type="time"
    //             className="w-full p-3 rounded-xl border border-gray-300 focus:outline-none focus:ring"
    //           />
    //           <button
    //             onClick={() => setShowModal(false)}
    //             className="w-full mt-6 bg-[rgba(5,35,68,1)] text-white py-2 rounded-lg"
    //           >
    //             Proceed
    //           </button>
    //         </div>
    //       </div>
    //     </div>
    //   )}


    // </div>
  );
};

export default OrderTable;
