import React from 'react'

const Shops = () => {
    return (
        <div>Shops</div>
    )
}

export default Shops