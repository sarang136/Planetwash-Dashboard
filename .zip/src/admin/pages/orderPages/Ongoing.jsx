import { useNavigate } from 'react-router-dom';
import { useGetUserOrdersByStatusQuery } from '../../redux/appSlice';



const Ongoing = () => {
  const navigate = useNavigate();
  const { data, isLoading, error } = useGetUserOrdersByStatusQuery("ongoing");
  console.log(data);
  

  if (isLoading) return <p className="text-center text-gray-500 py-6">Loading...</p>;
  if (error) return <p className="text-center text-gray-500 py-6"> No Orders Found</p>;

  const completedOrders = data?.orders || [];

  return (
    
    <div className="w-[auto] md:w-[unset] md:p-0">
      <div className="overflow-scroll bg-white rounded-xl shadow max-h-[75vh] px-0 md:px-4">
        <table className="min-w-full text-sm text-left">
          <thead className="text-black font-semibold sticky top-0 bg-white z-10">
            <tr>
              <th className="px-4 py-2 whitespace-nowrap">Customer Name</th>
              <th className="px-4 py-2 whitespace-nowrap">Contact No</th>
              <th className="px-4 py-2">Email</th>
              <th className="px-4 py-2">Service Type</th>
              <th className="px-4 py-2">Delivered By</th>
              <th className="px-4 py-2">Address</th>
              <th className="px-4 py-2">Payment</th>
              <th className="px-4 py-2">Delivered On</th>
            </tr>
          </thead>
          <tbody className="text-gray-400 border-t">
            {completedOrders.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center text-gray-500 py-6">
                  No completed orders found
                </td>
              </tr>
            ) : (
              completedOrders.map((order, index) => {
                const {
                  addressId,
                  serviceType,
                  deliveryBoyName,
                  deliveryBoyContact,
                  orderStatus,
                  paymentMethod,
                  deliveryDate,
                  services,
                  _id,
                } = order;

                return (
                  <tr key={index}>
                    <td className="px-4 py-2"
                     onClick={() => navigate(`/home/userData/${_id}`)}
                    >{addressId?.name}</td>
                    <td className="px-4 py-2">{addressId?.contactNo}</td>
                    <td className="px-4 py-2">{addressId?.email}</td>
                    <td className="px-4 py-2">{services[0]?.serviceId?.name}</td>
                    <td className="px-4 py-2">
                      {deliveryBoyName}<br />{deliveryBoyContact}
                    </td>
                    <td className="px-4 py-2">
                      {addressId?.location}, {addressId?.pincode}
                    </td>
                    <td className="px-4 py-2 capitalize">{paymentMethod || "Cash on Delivery"}</td>
                    <td className="px-4 py-2">
                      {order.updatedAt}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
      {/* <TemporaryComponent/> */}
    </div>
  );
};

export default Ongoing;
